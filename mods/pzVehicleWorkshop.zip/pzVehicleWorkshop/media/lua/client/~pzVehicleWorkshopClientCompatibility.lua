require "pzVehicleWorkshop/UI_patches"

require "Vehicles/ISUI/ISVehicleMechanics"
pzVehicleWorkshop.UI.patchISVehicleMechanics(ISVehicleMechanics)
